﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        protected Vehicle(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }
        public double FuelQuantity { get;  set; }
        public virtual double FuelConsumption { get; set; }
        public bool CanDrive(double distance) => FuelQuantity - FuelConsumption * distance >= 0;

        public void DriveDistance(double distance)
        {
            if (CanDrive(distance))
            {
                FuelQuantity -= FuelConsumption * distance;
            }
        }

        public virtual void RefuelVehicle(double liters)
        {
            FuelQuantity += liters;
        }
    }
}
