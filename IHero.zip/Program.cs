﻿using System;
using System.Collections.Generic;

namespace Raiding
{
    public class Program
    {
        static void Main(string[] args)
        {

            int totalPower = 0;

            int heroesToCreate = int.Parse(Console.ReadLine());

            for (int i = 0; i < heroesToCreate; i++)
            {
                string heroName = Console.ReadLine();
                string heroType = Console.ReadLine();

                IHero hero = null;

                if (heroType == "Druid")
                {
                    hero = new Druid(heroName);
                    Console.WriteLine(hero.CastAbility(heroName));
                }
                else if (heroType == "Paladin")
                {
                    hero = new Paladin(heroName);
                    Console.WriteLine(hero.CastAbility(heroName));
                }
                else if (heroType == "Rogue")
                {
                    hero = new Rogue(heroName);
                    Console.WriteLine(hero.CastAbility(heroName));
                }
                else if (heroType == "Warrior")
                {
                    hero = new Warrior(heroName);
                    Console.WriteLine(hero.CastAbility(heroName));
                }
                else
                {
                    Console.WriteLine("Invalid hero!");
                }

                if (hero != null)
                {
                    totalPower += hero.Power;
                }
            }

            int bossHp = int.Parse(Console.ReadLine());

            if (totalPower >= bossHp)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }
        }
    }
}
