﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class Paladin : HealerClass
    {
        public Paladin(string name) : base(name) {}
        public override int Power => 100;

        public override string CastAbility(string type)
        {
            return $"{base.CastAbility(type)} healed for {Power}";
        }
    }
}
