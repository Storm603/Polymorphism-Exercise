﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    interface IHero
    {
        public int Power { get; }
        public string CastAbility(string name);
    }
}
