﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace Raiding
{
    public abstract class BaseHero : IHero
    {

        protected BaseHero(string name)
        {
            Name = name;
        }

        public string Name { get;}
        public abstract int Power { get; }

        public virtual string CastAbility(string type)
        {
            return $"{GetType().Name} - {Name}";
        }
    }
}
