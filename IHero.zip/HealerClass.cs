﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public abstract class HealerClass : BaseHero
    {
        protected HealerClass(string name) : base(name) { }
        public override string CastAbility(string type)
        {
            return $"{base.CastAbility(type)}";
        }
    }
}
