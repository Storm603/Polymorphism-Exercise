﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public class Druid : HealerClass
    {
        public Druid(string name) : base(name) {}
        public override int Power => 80;
        public override string CastAbility(string type)
        {
            return $"{base.CastAbility(type)} healed for {Power}";
        }
    }
}
