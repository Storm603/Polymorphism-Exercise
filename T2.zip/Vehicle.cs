﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        protected Vehicle(double fuelQuantity, double fuelConsumption, double tankCapacity)
        {
            this.TankCapacity = tankCapacity;
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public double TankCapacity { get; set; }
        private double fuelQuantity;
        public double FuelQuantity
        {
            get { return fuelQuantity; }
            set
            {
                if (value > TankCapacity)
                {
                    fuelQuantity = 0;
                }
                else
                {
                    fuelQuantity = value;
                }
            }
        }
        public virtual double FuelConsumption { get; set; }
        public bool CanDrive(double distance) => FuelQuantity - FuelConsumption * distance >= 0;

        public void DriveDistance(double distance)
        {
            if (CanDrive(distance))
            {
                FuelQuantity -= FuelConsumption * distance;
            }
            else
            {
                Console.WriteLine($"Truck needs refueling");
            }
        }

        public virtual void RefuelVehicle(double liters)
        {
            if (fuelQuantity + liters > TankCapacity)
            {
                Console.WriteLine($"Cannot fit {liters} fuel in the tank");
            }
            else if (liters <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");
            }
            else
            {
                FuelQuantity += liters;
            }
        }

        public void EmptyOrNot(string state, double distance)
        {
            if (state == "Drive")
            {
                FuelConsumption += 1.4;
            }

            DriveDistance(distance);

            if (state == "Drive")
            {
                FuelConsumption -= 1.4;
            }
        }
    }
}
