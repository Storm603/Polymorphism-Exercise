﻿using System;

namespace Vehicles
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carInput = Console.ReadLine().Split();

            Vehicle car = new Car(double.Parse(carInput[1]), double.Parse(carInput[2]), double.Parse(carInput[3]));

            string[] truckInput = Console.ReadLine().Split();

            Vehicle truck = new Truck(double.Parse(truckInput[1]), double.Parse(truckInput[2]), double.Parse(truckInput[3]));

            string[] busInput = Console.ReadLine().Split();

            Vehicle bus = new Bus(double.Parse(busInput[1]), double.Parse(busInput[2]), double.Parse(busInput[3]));

            int commands = int.Parse(Console.ReadLine());

            for (int i = 0; i < commands; i++)
            {
                string[] arr = Console.ReadLine().Split();

                if (arr[0] == "Drive" || arr[0] == "DriveEmpty")
                {
                    if (arr[1] == "Car")
                    {
                        if (car.CanDrive(double.Parse(arr[2])))
                        {
                            car.DriveDistance(double.Parse(arr[2]));
                            Console.WriteLine($"Car travelled {arr[2]} km");
                        }
                        else
                        {
                            Console.WriteLine("Car needs refueling");
                        }
                    }
                    else if (arr[1] == "Truck")
                    {
                        if (truck.CanDrive(double.Parse(arr[2])))
                        {
                            truck.DriveDistance(double.Parse(arr[2]));
                            Console.WriteLine($"Truck travelled {arr[2]} km");
                        }
                        else
                        {
                            Console.WriteLine($"Truck needs refueling");
                        }
                    }
                    else if (arr[1] == "Bus")
                    {
                        if (bus.CanDrive(double.Parse(arr[2])))
                        {
                            bus.EmptyOrNot(arr[0], double.Parse(arr[2]));
                            Console.WriteLine($"Bus travelled {arr[2]} km");
                        }
                        else
                        {
                            Console.WriteLine($"Bus needs refueling");
                        }
                    }
                }
                else if (arr[0] == "Refuel")
                {
                    if (arr[1] == "Car")
                    {
                        car.RefuelVehicle(double.Parse(arr[2]));
                    }
                    else if(arr[1] == "Truck")
                    {
                        truck.RefuelVehicle(double.Parse(arr[2]));
                    }
                    else if (arr[1] == "Bus")
                    {
                        bus.RefuelVehicle(double.Parse(arr[2]));
                    }
                }
            }
            
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:f2}");
        }
    }
}
